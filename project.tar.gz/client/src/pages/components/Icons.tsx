export const iconsPath = {
    technology: '/src/assets/icons/technology-icon.svg',
    trip: '/src/assets/icons/trip-icon.svg',
    programming: '/src/assets/icons/programming-icon.svg',
    cooking: '/src/assets/icons/cooking-icon.svg',
    art: '/src/assets/icons/art-icon.svg',
    politics: '/src/assets/icons/politic-icon.svg',
    sport: '/src/assets/icons/sport-icon.svg',
    history: '/src/assets/icons/history-icon.svg',
    music: '/src/assets/icons/music-icon.svg',
} as const;